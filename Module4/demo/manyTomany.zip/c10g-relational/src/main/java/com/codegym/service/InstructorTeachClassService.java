package com.codegym.service;

import com.codegym.entity.InstructorTeachClass;

public interface InstructorTeachClassService {

    void save(InstructorTeachClass instructorTeachClass);
}
