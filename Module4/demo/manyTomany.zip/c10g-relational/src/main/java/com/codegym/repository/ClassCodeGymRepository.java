package com.codegym.repository;

import com.codegym.entity.ClassCodeGym;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassCodeGymRepository extends JpaRepository<ClassCodeGym, Integer> {
}
