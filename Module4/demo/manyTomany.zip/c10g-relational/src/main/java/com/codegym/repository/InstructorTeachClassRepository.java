package com.codegym.repository;

import com.codegym.entity.InstructorTeachClass;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstructorTeachClassRepository extends JpaRepository<InstructorTeachClass, Integer> {
}
