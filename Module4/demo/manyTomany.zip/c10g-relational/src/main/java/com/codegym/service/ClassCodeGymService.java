package com.codegym.service;

import com.codegym.entity.ClassCodeGym;

public interface ClassCodeGymService {

    ClassCodeGym findById(Integer id);
}
