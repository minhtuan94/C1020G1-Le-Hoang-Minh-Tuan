package com.codegym.service;

public interface StudentService {
}
