package com.codegym.service;

import com.codegym.entity.ClassRoom;

import java.util.List;

public interface ClassRoomService {
    List<ClassRoom> findAll();
}
