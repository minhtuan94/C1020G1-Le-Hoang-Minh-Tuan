package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelftestSpringWebserviceRestfulApplication {

    public static void main(String[] args) {
        SpringApplication.run(SelftestSpringWebserviceRestfulApplication.class, args);
    }

}
